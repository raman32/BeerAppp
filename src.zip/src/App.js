import React, { Component } from "react";
import "./App.css";
import MainPage from "./MainPage";
class App extends Component {
  render() {
    return <MainPage />;
  }
}

export default App;
