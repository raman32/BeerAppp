import React, { Component } from "react";
import "./TopPanel.css";
import "./bootstrap.css";

class TopPanel extends Component {
  constructor(props) {
    super(props);
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      abv_gt: null,
      abv_lt: null,
      ibu_gt: null,
      ibu_lt: null,
      ebc_gt: null,
      ebc_lt: null,
      brewed_before: null,
      brewed_after: null
    };
  }
  handleSubmit() {
    this.props.handleSubmit(this.state);
  }
  handleNumber(event, id) {
    let temp = event.target.value;
    if (parseInt(temp) && parseInt(temp) >= 0) {
      this.setState({ [id]: parseInt(temp) });
    }
  }
  handleDate(event, id) {
    let temp = event.target.value;
    let value = "";
    if (temp[0] === "0" || temp[0] === "1") {
      value = temp[0];
      if (parseInt(temp[1])) {
        value += temp[1] + "-";
        if (parseInt(temp[3])) {
          value += temp[3];
          if (parseInt(temp[4])) {
            value += temp[4];
            if (parseInt(temp[5])) {
              value += temp[5];
              if (parseInt(temp[6])) {
                value += temp[6];
              }
            }
          }
        }
      }
    }
    this.setState({ id: value });
  }
  handleChange(event) {
    this.props.onChangehandler(event.target.value);
  }

  render() {
    let link = this.props.link;
    let search = this.props.searchTerm;
    let navigation;
    let searchbar = (
      <div>
        <input
          className="search-navbar"
          type="text"
          onChange={this.handleChange}
          value={search}
        />
        <div className="text-center row">
          <div className="col-4" />
          <div
            className="col-4 "
            onClick={() => this.props.onChangehandlerPage("advance-search")}
          >
            Click Here for Advance Search
          </div>
        </div>
      </div>
    );
    if (link === "home") {
      navigation = (
        <div className="links d-flex flex-row-reverse sticky-top">
          <div className="link-clicked-navigation link-property ">HOME</div>
          <div
            onClick={() => this.props.onChangehandlerPage("favorite")}
            className="link-property"
          >
            FAVORITE
          </div>
        </div>
      );
    } else if (link === "favorite") {
      navigation = (
        <div className="links d-flex flex-row-reverse sticky-top">
          <div
            onClick={() => this.props.onChangehandlerPage("home")}
            className="link-property"
          >
            HOME
          </div>
          <div className="link-clicked-navigation link-property ">FAVORITE</div>
        </div>
      );
    } else if (link === "advance-search") {
      navigation = (
        <div className="links d-flex flex-row-reverse sticky-top">
          <div
            onClick={() => this.props.onChangehandlerPage("home")}
            className="link-property"
          >
            HOME
          </div>
          <div
            className="link-property"
            onClick={() => this.props.onChangehandlerPage("favorite")}
          >
            FAVORITE
          </div>
        </div>
      );
      searchbar = (
        <div>
          <form className="row">
            <div>
              <label>Max IBU</label>
              <input
                type="text"
                onChange={event => this.handleNumber(event, "ibu_gt")}
                value={this.state.ibu_gt}
              />
            </div>
            <div>
              <label>Min IBU</label>
              <input
                type="text"
                onChange={event => this.handleNumber(event, "ibu_lt")}
                value={this.state.ibu_lt}
              />
            </div>
            <div>
              <label>Max ABV</label>
              <input
                type="text"
                onChange={event => this.handleNumber(event, "abv_gt")}
                value={this.state.abv_gt}
              />
            </div>
            <div>
              <label>Min ABV</label>
              <input
                type="text"
                onChange={event => this.handleNumber(event, "abv_lt")}
                value={this.state.abv_lt}
              />
            </div>

            <div>
              <label>Max EBC</label>
              <input
                type="text"
                onChange={event => this.handleNumber(event, "ebc_gt")}
                value={this.state.ebc_gt}
              />
            </div>
            <div>
              <label>Min EBC</label>
              <input
                type="text"
                onChange={event => this.handleNumber(event, "ebc_lt")}
                value={this.state.ebc_lt}
              />
            </div>

            <div>
              <label>Brewed Before</label>
              <input
                type="text"
                onChange={event => this.handleDate(event, "brewed_before")}
                value={this.state.brewed_before}
              />
            </div>
            <div>
              <label>Brewed After</label>
              <input
                type="text"
                onChange={event => this.handleDate(event, "brewed_after")}
                value={this.state.brewed_after}
              />
            </div>
            <input type="button" value="Submit" onClick={this.handleSubmit} />
          </form>
        </div>
      );
    }

    return (
      <div className="top-panel">
        <p>{navigation}</p>
        <div className="title-with-searchbar">
          <div>
            <p className="title-text font-weight-bold">The Beer Bank</p>
            <p className="title-description">Find Your Favorite Beer Here</p>
          </div>
          {searchbar}
        </div>
      </div>
    );
  }
}
export default TopPanel;
