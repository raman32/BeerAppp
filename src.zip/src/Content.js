import React, { Component } from "react";
import BeerDisplay from "./BeerDisplay";
import "./Content.css";
import "./bootstrap.css";

class Content extends Component {
  constructor(props) {
    super(props);
    this.handleOnScroll = this.handleOnScroll.bind(this);
    this.state = {
      BeerProducts: [],
      fetchComplete: false,
      page: 1,
      CompleteBeerProduct: [],
      searchTerm: ""
    };
    this.getData = this.getData.bind(this);
  }
  getData() {
    let temp = {
      beer_name: this.props.searchTerm,
      page: this.state.page.toString()
    };
    let queryString = "";
    let tempString = temp.toString();
    let odd = false;
    for (let value of tempString) {
      queryString += value;
      if (odd) {
        queryString += "=";
      } else {
        queryString += "&";
      }
      odd = !odd;
    }

    fetch("https://api.punkapi.com/v2/beers?" + queryString, {
      method: "GET"
    })
      .then(response => response.json())
      .then(findresponse => {
        this.setState({
          BeerProducts: findresponse
        });
        this.setState({
          fetchComplete: true
        });
      });
  }
  componentDidMount() {
    this.getData();

    window.addEventListener("scroll", this.handleOnScroll);
  }
  componentWillUnmount() {
    window.removeEventListener("scroll", this.handleOnScroll);
  }
  handleOnScroll() {
    var scrollTop =
      (document.documentElement && document.documentElement.scrollTop) ||
      document.body.scrollTop;
    var scrollHeight =
      (document.documentElement && document.documentElement.scrollHeight) ||
      document.body.scrollHeight;
    var clientHeight =
      document.documentElement.clientHeight || window.innerHeight;
    var scrolledToBottom = Math.ceil(scrollTop + clientHeight) >= scrollHeight;
    console.log(scrollHeight, clientHeight, scrollTop);
    if (scrolledToBottom && this.props.page === "home") {
      let currentPage = this.state.page;
      this.setState({ page: currentPage + 1 });
      this.getData();
      let temp = this.state.CompleteBeerProduct.slice();
      this.setState({
        CompleteBeerProduct: temp.concat(this.state.BeerProducts)
      });
      console.log("Reached the end");
    }
  }

  render() {
    if (this.state.searchTerm !== this.props.searchTerm) {
      this.setState({ searchTerm: this.props.searchTerm });
    }
    // console.log(this.state.searchTerm, this.props.searchTerm);
    let page = this.props.page;
    let favorite = false;
    let searchTerm = this.state.searchTerm;
    let display = [];
    searchTerm = searchTerm.trim().toLowerCase();

    if (this.state.fetchComplete) {
      if (!this.state.CompleteBeerProduct.length) {
        this.setState({ CompleteBeerProduct: this.state.BeerProducts.slice() });
        // console.log(this.state.BeerProducts);
      }
      let BeerProductsfiltered = this.state.CompleteBeerProduct.slice();
      if (searchTerm.length > 0) {
        BeerProductsfiltered = this.state.CompleteBeerProduct.filter(function(
          i
        ) {
          return i.name.toLowerCase().match(searchTerm);
        });
      }
      if (page === "home") {
        for (let value of BeerProductsfiltered) {
          favorite = false;
          for (let a of this.props.favorite) {
            if (a === value) {
              favorite = true;
            }
          }
          display.push(
            <BeerDisplay
              className="col-sm-3 col-md-6 col-lg-4 ml-auto"
              favorite={favorite}
              onAddFavorite={this.props.addFavorite}
              onRemoveFavorite={this.props.removeFavorite}
              BeerProducts={value}
              BeerProductsArray={BeerProductsfiltered}
              favoriteArray={this.props.favorite}
            />
          );
        }
      } else if (page === "favorite") {
        for (let value of this.props.favorite) {
          display.push(
            <BeerDisplay
              className="col-sm-3 col-md-6 col-lg-4 ml-auto"
              favorite={true}
              onRemoveFavorite={this.props.removeFavorite}
              BeerProducts={value}
              BeerProductsArray={BeerProductsfiltered}
              favoriteArray={this.props.favorite}
            />
          );
        }
      } else {
        display = <div id="content-page "> Loading </div>;
      }
    }

    return (
      <div className="row" id="content-page">
        {display}
      </div>
    );
  }
}
export default Content;
